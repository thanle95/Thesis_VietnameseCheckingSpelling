﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spell.Algorithm
{
    public class VNDictionary
    {
        public List<string> SyllableDict;
        public List<string> CompoundDict;

        private VNDictionary()
        {
            this.SyllableDict = new List<string>();
            this.SyllableDict = readSyllableDict();
            this.CompoundDict = new List<string>();
            this.CompoundDict = readCompoundWordDict();
        }

        private static VNDictionary instance = new VNDictionary();
        public static VNDictionary getInstance
        {
            get
            {
                return instance;
            }
        }


        /// <summary>
        /// Đọc từ điển tiếng âm tiết lên
        /// </summary>
        public List<string> readSyllableDict()
        {

            List<string> result = new List<string>();
            try
            {
                //properties vào fileName, chọn copy always
                string[] tempDict = File.ReadAllLines(@"Resources\mySyllableDict.txt");
                foreach (string i in tempDict)
                {
                    result.Add(i);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("khong doc duoc file");
            }
            return result;
        }
        /// <summary>
        /// đọc từ điển từ ghép tiếng Việt
        /// </summary>
        /// <returns></returns>
        public List<string> readCompoundWordDict()
        {
            List<string> result = new List<string>(); try
            {
                string[] tempDict = File.ReadAllLines(@"Resources\compoundWordDict.txt");
                foreach (string i in tempDict)
                {
                    result.Add(i.ToLower());
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("khong doc duoc file");
            }
            return result;
        }
        /// <summary>
        /// Kiểm tra một token có là âm tiết tiếng Việt hay không
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public bool isSyllableVN(string token)
        {
            // dung giai thuat tim kiem am tiet 'token' trong tu dien
            // Neu co am tiet nay thi return true

            return this.SyllableDict.BinarySearch(token.ToLower()) >= 0; // Neu am tiet nay ko co trong tu dien 
        }
        /// <summary>
        /// Kiểm tra một cụm từ có là từ ghép hay không
        /// </summary>
        /// <param name="word"></param>
        /// <returns></returns>
        public bool isCompoundVN(string word)
        {
            return this.CompoundDict.BinarySearch((word).ToLower()) >= 0;
        }
        /// <summary>
        /// trả về từ ghép liền trước token
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public HashSet<string> findCompoundVNWord_pre(string token)
        {
            HashSet<string> hSetResult = new HashSet<string>();
            if (token.Length > 0)
                foreach (string i in CompoundDict)
                {
                    if (i.Contains(token))
                    {
                        string[] tmpArr = i.Split(' ');
                        for (int iTmpArr = 0; iTmpArr < tmpArr.Length; iTmpArr++)
                        {
                            if (tmpArr[iTmpArr].Equals(token) && iTmpArr != 0)
                            {
                                hSetResult.Add(tmpArr[iTmpArr - 1]);
                            }
                        }

                    }

                }
            else
                hSetResult.Add("");
            return hSetResult;
        }
        /// <summary>
        /// trả về từ ghép liền sau token
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public HashSet<string> findCompoundVNWord_next(string token)
        {
            HashSet<string> hSetResult = new HashSet<string>();
            if (token.Length > 0)
                foreach (string i in CompoundDict)
                {
                    if (i.Contains(token))
                    {
                        string[] tmpArr = i.Split(' ');
                        for (int iTmpArr = 0; iTmpArr < tmpArr.Length; iTmpArr++)
                        {
                            if (tmpArr[iTmpArr].Equals(token) && iTmpArr != tmpArr.Length - 1)
                            {
                                hSetResult.Add(tmpArr[iTmpArr + 1]);
                            }
                        }

                    }

                }
            else
                hSetResult.Add("");
            return hSetResult;
        }
        /// <summary>
        /// kiểm tra một từ có là từ láy tiếng Việt hay không
        /// </summary>
        /// <param name="words"></param>
        /// <returns></returns>
        public bool isReduplicativeWordsVN(string words)
        {
            return false;
        }
    }
}
