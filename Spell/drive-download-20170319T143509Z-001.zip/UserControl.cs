﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Spell.Algorithm;
using Word = Microsoft.Office.Interop.Word;
using Office = Microsoft.Office.Core;
using System.Threading;

namespace Spell
{

    public enum Position { xxX, xXx, Xxx, xX, Xx, X };
    public partial class UserControl : System.Windows.Forms.UserControl
    {
        private Word.Range curRangeTextShowInTaskPane;
        
        private static UserControl instance = new UserControl();
        private Dictionary<string, List<string>> globalsCandidates;
        private UserControl()
        {
            globalsCandidates = new Dictionary<string, List<string>>();
            InitializeComponent();
        }

        public static UserControl Instance
        {
            get
            {
                return instance;
            }
        }

        private void lstbCandidate_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblFix.Text = lstbCandidate.SelectedItem.ToString();
        }

      
        /// <summary>
        /// hiện gợi ý lên task pane
        /// </summary>
        /// <param name="w">từ lỗi</param>
        public void showCandidates(string prepre, string pre, Word.Range range, string next, string nextnext)
        {
            //if (Globals.ThisAddIn.Application.Selection.Text.Length > 1)
            //{
            //    curRangeTextShowInTaskPane = Globals.ThisAddIn.Application.Selection.Range;

            //    string w = curRangeTextShowInTaskPane.Text.Trim();

            //    if (w.Length > 0)
            //    {
            //        List<string> items = NewUtility.Instance.generateCandidatePerWord(w);
            //        lblWrong.Text = w;
            //        lstbCandidate.Items.Clear();
            //        lstbCandidate.Items.Add(w);
            //        foreach (string item in items)
            //            if (!item.ToLower().Equals(w.ToLower()))
            //                if(item.Length > 1)
            //                lstbCandidate.Items.Add(item);
            //    }
            //}
            //while (true)
            //{
            string token = range.Text;
            if (token.Length > 0)
            {
                HashSet<string> items = Candidate.getInstance.selectiveCandidate(prepre, pre, token, next, nextnext);
                lblWrong.Text = token;
                lstbCandidate.Items.Clear();
                //lstbCandidate.Items.Add(token);
                foreach (string item in items)
                    if (!item.ToLower().Equals(token.ToLower()))
                        if (item.Length > 1)
                            lstbCandidate.Items.Add(item.Trim());
            }
            //}
        }
        /// <summary>
        /// HighLight tất cả những lỗi mà không hiện gợi ý
        /// </summary>
        public void showWrongWithoutSuggest()
        {
            while (true)
            {
                DocumentHandling.Instance.DeHighLight_All_Mistake(Globals.ThisAddIn.Application.ActiveDocument.Characters);
                Word.Sentences sentences = Globals.ThisAddIn.Application.ActiveDocument.Sentences;
                List<string> mySentences = DocumentHandling.Instance.getPhrase(sentences);
                Word.Words globalWords = Globals.ThisAddIn.Application.ActiveDocument.Words;

                //Xử lý từng cụm từ, vì mỗi cụm từ có liên quan mật thiết với nhau
                foreach (string sentence in mySentences)
                {
                    string[] words = sentence.Trim().Split(' ');
                    int length = words.Length;
                    for (int i = 0; i < length; i++)
                    {
                        string word = words[i].Trim();

                        //Kiểm tra nếu không phải là từ Việt Nam
                        //Thì highLight
                        if (!NewUtility.Instance.isVietNameseWithoutContext(word))
                        {
                            DocumentHandling.Instance.HighLight_Mistake(word, globalWords);
                        }

                        //dựa vào ngữ cảnh: bắt đầu
                        //chưa phải từ cuối cùng
                        if (i < length - 1)
                        {
                            //câu có hơn 1 từ, và nếu đang là từ đầu tiên
                            if (i == 0)
                            {
                                if (!NewUtility.Instance.isVietNameseWithContext_beginSentence(word, words[i + 1].Trim()))
                                    DocumentHandling.Instance.HighLight_Mistake(word, globalWords);
                            }
                            else
                            {
                                if (!NewUtility.Instance.isVietNameseWithContext_midSentence(words[i - 1].Trim(), word, words[i + 1].Trim()))
                                    DocumentHandling.Instance.HighLight_Mistake(word, globalWords);
                            }
                        }
                        else
                        {
                            if (length != 1)
                                if (!NewUtility.Instance.isVietNameseWithContext_endSentence(words[i - 1].Trim(), word))
                                    DocumentHandling.Instance.HighLight_Mistake(word, globalWords);
                        }
                        //dựa vào ngữ cảnh: kết thúc

                    }
                }
                Thread.Sleep(5000);
            }
        }
        /// <summary>
        /// HighLight lỗi hiện tại và hiện gợi ý
        /// </summary>
        public void showWrongWithSuggest()
        {
            try
            {
                //while (true)
                //{
                globalsCandidates.Clear();
                DocumentHandling.Instance.DeHighLight_All_Mistake(Globals.ThisAddIn.Application.ActiveDocument.Characters);
                Word.Sentences sentences = Globals.ThisAddIn.Application.ActiveDocument.Sentences;
                List<string> mySentences = DocumentHandling.Instance.getPhrase(sentences);
                Word.Words globalWords = Globals.ThisAddIn.Application.ActiveDocument.Words;
                bool isFault = false;

                //Xử lý từng cụm từ, vì mỗi cụm từ có liên quan mật thiết với nhau
                foreach (string sentence in mySentences)
                {
                    string[] words = sentence.Trim().Split(' ');
                    int length = words.Length;
                    for (int i = 0; i < length; i++)
                    {
                        string word = words[i].Trim();

                        //Kiểm tra nếu không phải là từ Việt Nam
                        //Thì highLight
                        //if (!NewUtility.Instance.isVietNameseWithoutContext(word))
                        if (!VNDictionary.getInstance.isSyllableVN(word))
                        {
                            curRangeTextShowInTaskPane = DocumentHandling.Instance.HighLight_Mistake(word, globalWords);
                            isFault = true;
                        }


                        ////dựa vào ngữ cảnh: bắt đầu
                        ////chưa phải từ cuối cùng
                        //if (i < length - 1)
                        //{
                        //    //câu có hơn 1 từ, và nếu đang là từ đầu tiên
                        //    if (i == 0)
                        //    {
                        //        if (!NewUtility.Instance.isVietNameseWithContext_beginSentence(word, words[i + 1].Trim()))
                        //        {
                        //            curRangeTextShowInTaskPane = DocumentHandling.Instance.HighLight_Mistake(word, globalWords);
                        //            isFault = true;
                        //        }
                        //    }
                        //    else
                        //    {
                        //        if (!NewUtility.Instance.isVietNameseWithContext_midSentence(words[i - 1].Trim(), word, words[i + 1].Trim()))
                        //        {
                        //            curRangeTextShowInTaskPane = DocumentHandling.Instance.HighLight_Mistake(word, globalWords);
                        //            isFault = true;
                        //        }
                        //    }
                        //}
                        ////từ cuối cùng
                        //else
                        //{
                        //    if (length != 1)
                        //        if (!NewUtility.Instance.isVietNameseWithContext_endSentence(words[i - 1].Trim(), word))
                        //        {
                        //            curRangeTextShowInTaskPane = DocumentHandling.Instance.HighLight_Mistake(word, globalWords);
                        //            isFault = true;
                        //        }
                        //}
                        ////dựa vào ngữ cảnh: kết thúc

                        if (isFault)
                        {
                            string prepre = "", pre = "", next = "", nextnext = "";
                            if(i == 0)
                            {
                                if (length > 1)
                                    next = words[i + 1].Trim().ToLower();
                                if (length > 2)
                                    nextnext = words[i + 2].Trim().ToLower();
                            }
                            else if(i == 1)
                            {
                                if (length > 1)
                                    pre = words[i - 1].Trim().ToLower();
                                if (length > 2)
                                    next = words[i + 1].Trim().ToLower();
                                if (length > 3)
                                    nextnext = words[i + 2].Trim().ToLower();
                            }
                            else if(i == 2)
                            {
                                if (length > 2)
                                {
                                    prepre = words[i - 2].Trim().ToLower();
                                    pre = words[i - 1].Trim().ToLower();
                                }
                                if (length > 3)
                                    next = words[i + 1].Trim().ToLower();
                                if (length > 4)
                                    nextnext = words[i + 2].Trim().ToLower();
                            }
                            else if(i > 2 && i < length - 2)
                            {
                                if(length > 5)
                                {
                                    prepre = words[i - 2].Trim().ToLower();
                                    pre = words[i - 1].Trim().ToLower();
                                    next = words[i + 1].Trim().ToLower();
                                    nextnext = words[i + 2].Trim().ToLower();
                                }
                            }
                            else if(i == length - 2)
                            {
                                if (length > 2)
                                {
                                    pre = words[i - 1].Trim().ToLower();
                                    next = words[i + 1].Trim().ToLower();
                                }
                                if (length > 3)
                                    prepre = words[i -2].Trim().ToLower();
                            }
                            else if(i == length - 1)
                            {
                                if (length > 1)
                                    pre = words[i - 1].Trim().ToLower();
                                if (length > 2)
                                    prepre = words[i - 2].Trim().ToLower();
                            }
                            showCandidates(prepre, pre, curRangeTextShowInTaskPane, next, nextnext);

                            isFault = false;

                        }
                    }//end for
                }
                //Thread.Sleep(5000);
                //}
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }
        //
        //---Kiet Start
        //

        // button Ignore
        // unhighlight all word 
        private void btnIgnore_Click(object sender, EventArgs e)
        {
            ignore(); // Goi phuong thuc ignore de thuc hien deHighlight
        }

        private void ignore()
        {
            DocumentHandling.Instance.DeHighLight_All_Mistake(curRangeTextShowInTaskPane.Start, curRangeTextShowInTaskPane.End);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ignore();
            Ngram.Instance.addToDictionary(lblWrong.Text, null, null, Position.X);
        }

        private void btnTest_Click(object sender, EventArgs e)
        {

        }

        private void UserControl_Load(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            showWrongWithSuggest();
            //foreach (string i in VNDictionary.getInstance.findCompoundVNWord_next("vi"))
            //    if (i.Equals("tính"))
            //        MessageBox.Show(i);
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            curRangeTextShowInTaskPane.Text = lstbCandidate.SelectedItem.ToString();
            lblWrong.Text = "\"Wrong Text\"";
            lblFix.Text = "\"Fix Text\"";
            lstbCandidate.Items.Clear();
            DocumentHandling.Instance.DeHighLight_All_Mistake(Globals.ThisAddIn.Application.ActiveDocument.Characters);
            //Globals.ThisAddIn.Application.Selection.GoTo(Word.WdGoToItem.wdGoToLine, Word.WdGoToDirection.wdGoToAbsolute, 3);
            curRangeTextShowInTaskPane.Select();
        }



        //
        //---Kiet End
        //
    }
}
